/**
 *  ╒══════════════════════════════════════╕
 *  │                                      │
 *  │             Doodle Jump              │
 *  │        Advanced Programming          │
 *  │                                      │
 *  │            Robbe Nooyens             │
 *  │    s0201010@student.uantwerpen.be    │
 *  │                                      │
 *  │        University of Antwerp         │
 *  │                                      │
 *  ╘══════════════════════════════════════╛
 */

#ifndef DOODLEJUMP_PLATFORMTYPE_H
#define DOODLEJUMP_PLATFORMTYPE_H

/**
 * @brief Represents a platform type
 */
enum PlatformType {STATIC, HORIZONTAL, VERTICAL, TEMPORARY};

#endif //DOODLEJUMP_PLATFORMTYPE_H
