/**
 *  ╒══════════════════════════════════════╕
 *  │                                      │
 *  │             Doodle Jump              │
 *  │        Advanced Programming          │
 *  │                                      │
 *  │            Robbe Nooyens             │
 *  │    s0201010@student.uantwerpen.be    │
 *  │                                      │
 *  │        University of Antwerp         │
 *  │                                      │
 *  ╘══════════════════════════════════════╛
 */

#ifndef DOODLEJUMP_BONUSTYPE_H
#define DOODLEJUMP_BONUSTYPE_H

/**
 * @brief Represents a bonus type
 */
enum BonusType {JETPACK, SPRING};

#endif //DOODLEJUMP_BONUSTYPE_H
